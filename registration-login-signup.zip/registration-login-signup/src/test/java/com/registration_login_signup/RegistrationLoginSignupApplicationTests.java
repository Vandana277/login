package com.registration_login_signup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationLoginSignupApplicationTests {

	@Test
	void contextLoads() {
	}

}
