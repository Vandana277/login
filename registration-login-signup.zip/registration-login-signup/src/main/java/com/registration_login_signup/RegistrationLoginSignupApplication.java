package com.registration_login_signup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication // (exclude = SecurityAutoConfiguration.class)


public class RegistrationLoginSignupApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationLoginSignupApplication.class, args);
	}

}
