package com.registration_login_signup.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.registration_login_signup.dto.LoginDto;
import com.registration_login_signup.dto.UserRegistrationDto;
import com.registration_login_signup.response.LoginResponse;
import com.registration_login_signup.service.UserService;


@RestController
@CrossOrigin
@RequestMapping("/user")

public class UserRegistrationController {

	@Autowired
	private UserService userService;

	@PostMapping(path = "/save")
	public String saveUser(@RequestBody UserRegistrationDto userRegistrationDto) {
		String id = userService.addUser(userRegistrationDto);
		return id;
	}

	@PostMapping(path = "/login")
	public ResponseEntity<?> loginUser(@RequestBody LoginDto loginDto) {
		LoginResponse loginResponse = userService.loginUser(loginDto);
		return ResponseEntity.ok(loginResponse);
	}

}
