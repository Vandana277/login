package com.registration_login_signup.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.registration_login_signup.dto.LoginDto;
import com.registration_login_signup.dto.UserRegistrationDto;
import com.registration_login_signup.entity.User;
import com.registration_login_signup.repository.UserRepository;
import com.registration_login_signup.response.LoginResponse;
import com.registration_login_signup.service.UserService;

@Service
@EnableWebSecurity
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;


	@Override
	public String addUser(UserRegistrationDto userRegistrationDto) {
		
		User user = new User();{
			
			userRegistrationDto.getFullname();
			userRegistrationDto.getGender();
			userRegistrationDto.getDob();
			userRegistrationDto.getAddress();
			userRegistrationDto.getEmail();
			userRegistrationDto.getPassword();
			
			this.passwordEncoder.encode(userRegistrationDto.getPassword());
		}
		
		userRepository.save(user);
		
		return user.getFullname();
	}

	@Override
	public LoginResponse loginUser(LoginDto loginDto) {
		String msg = " ";
		User user1 = userRepository.findByEmail(loginDto.getEmail());
		if(user1!=null) {
			String password = loginDto.getPassword();
			String encodedPassword = user1.getPassword();
			Boolean isPwdRight = passwordEncoder.matches(password, encodedPassword);
			if(isPwdRight) {
				Optional <User> user = userRepository.findOneByEmailAndPassword(loginDto.getEmail(), loginDto.getPassword());
				if(user.isPresent()) {
					return new LoginResponse("Login Success", true);
				}
				else {
					return new LoginResponse("Login Failed", false);
					}
			}
			else 
			{
				return new LoginResponse("Password not match", false);
				}
			}
			
		else {
				return new LoginResponse("Email not exists", false);
			}
		}
	}
		





