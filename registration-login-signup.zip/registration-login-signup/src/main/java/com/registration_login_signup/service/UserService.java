package com.registration_login_signup.service;

import com.registration_login_signup.dto.LoginDto;
import com.registration_login_signup.dto.UserRegistrationDto;
import com.registration_login_signup.response.LoginResponse;


public interface UserService {

	// User saveUser(UserRegistrationDto userRegistrationDto);

	String addUser(UserRegistrationDto userRegistrationDto);



	LoginResponse loginUser(LoginDto loginDto);
}
