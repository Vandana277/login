package com.registration_login_signup.payload.response;

public class LoginMessage {

}
